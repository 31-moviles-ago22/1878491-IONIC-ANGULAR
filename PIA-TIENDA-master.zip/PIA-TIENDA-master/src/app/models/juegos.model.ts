export interface Juego {
  id: number;
  title: string;
  price: number;
  image?: string;
  description?: string;
}
