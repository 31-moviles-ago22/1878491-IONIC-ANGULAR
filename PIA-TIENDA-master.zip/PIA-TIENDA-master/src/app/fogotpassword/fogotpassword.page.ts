import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fogotpassword',
  templateUrl: './fogotpassword.page.html',
  styleUrls: ['./fogotpassword.page.scss'],
})
export class FogotpasswordPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
